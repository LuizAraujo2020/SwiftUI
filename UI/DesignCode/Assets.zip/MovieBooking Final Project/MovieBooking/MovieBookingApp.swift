//
//  MovieBookingApp.swift
//  MovieBooking
//
//  Created by Willie Yam on 2022-08-16.
//

import SwiftUI

@main
struct MovieBookingApp: App {

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
